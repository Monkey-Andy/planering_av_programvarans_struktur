function alertHello() {
    alert("Hej!");
}
console.log("Jag klarade det!")